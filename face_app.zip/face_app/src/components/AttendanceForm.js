import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';

const AttendanceForm = () => {
  const [students, setStudents] = useState([]);
  const { userId } = useParams();
  const [attendance, setAttendance] = useState({
    student: userId || '', 
    status: 'Present',
    time_in: '',
    time_out: '',
    total_time_present: 0,
    total_time_absent: 0,
  });

  // Fetch students list
  useEffect(() => {
    axios
      .get('http://127.0.0.1:8000/api/students/')
      .then((response) => {
        setStudents(response.data);
      })
      .catch((error) => {
        console.error('Error fetching students:', error);
      });
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setAttendance((prevAttendance) => ({
      ...prevAttendance,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .post('http://127.0.0.1:8000/api/attendance/', attendance)
      .then((response) => {
        alert('Attendance submitted successfully');
        setAttendance({
          student: '',
          status: 'Present',
          time_in: '',
          time_out: '',
          total_time_present: 0,
          total_time_absent: 0,
        });
      })
      .catch((error) => {
        console.error('Error submitting attendance:', error);
      });
  };

  return (
    <div>
      <h2>Mark Attendance</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label htmlFor="student">Student</label>
          <select
            id="student"
            name="student"
            value={attendance.student}
            onChange={handleChange}
            required
          >
            <option value="">Select Student</option>
            {students.map((student) => (
              <option key={student.id} value={student.id}>
                {student.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label htmlFor="status">Status</label>
          <select
            id="status"
            name="status"
            value={attendance.status}
            onChange={handleChange}
            required
          >
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
          </select>
        </div>

        <div>
          <label htmlFor="time_in">Time In</label>
          <input
            type="time"
            id="time_in"
            name="time_in"
            value={attendance.time_in}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label htmlFor="time_out">Time Out</label>
          <input
            type="time"
            id="time_out"
            name="time_out"
            value={attendance.time_out}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label htmlFor="total_time_present">Total Time Present (Minutes)</label>
          <input
            type="number"
            id="total_time_present"
            name="total_time_present"
            value={attendance.total_time_present}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <label htmlFor="total_time_absent">Total Time Absent (Minutes)</label>
          <input
            type="number"
            id="total_time_absent"
            name="total_time_absent"
            value={attendance.total_time_absent}
            onChange={handleChange}
            required
          />
        </div>

        <div>
          <button type="submit">Submit Attendance</button>
        </div>
      </form>
    </div>
  );
};

export default AttendanceForm;
