import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Box } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const ForgotPasswordPage = () => {

    const navigate = useNavigate();
    
    const [email, setEmail] = useState('');

    const handleChange = (e) => {
        setEmail(e.target.value);
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        console.log('Forgot Password submitted for email:', email);
        // Add backend API call for sending password reset email here
        navigate('/after-forgot')

    };

    return (
        <Container maxWidth="sm">
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    marginTop: 4,
                    padding: 4,
                    boxShadow: 3,
                    borderRadius: 2
                }}
            >
                <Typography variant="h4" component="h1" gutterBottom>
                    Forgot Password
                </Typography>
                <Typography variant="body1" color="textSecondary" gutterBottom>
                    Enter your email address and we’ll send you a link to reset your password.
                </Typography>
                <form onSubmit={handleSubmit} style={{ width: '100%' }}>
                    <TextField
                        label="Email"
                        type="email"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        value={email}
                        onChange={handleChange}
                        required
                    />
                    <Button
                        type="submit"
                        variant="contained"
                        color="primary"
                        fullWidth
                        sx={{ marginTop: 2 }}
                    >
                        Send Reset Link
                    </Button>
                </form>
            </Box>
        </Container>
    );
};

export default ForgotPasswordPage;





