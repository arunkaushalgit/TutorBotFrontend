import React from 'react'

import UserNavbar from './UserNavbar'
import AwsCardsUser from '../AwsUser/AwsCardsUser'

function UserDashboard() {
  return (
    <>
    <UserNavbar/>
    <AwsCardsUser/>
      
    </>
  )
}

export default UserDashboard


