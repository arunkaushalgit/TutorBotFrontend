import React from 'react'

function Constructon() {
  return (
    <div>
      <h1>This page is under construction</h1>
    </div>
  )
}

export default Constructon
