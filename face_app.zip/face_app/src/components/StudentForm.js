import React, { useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { TextField, Button, Grid, Typography, Box, Input } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const StudentForm = () => {
  const { userId } = useParams(); // Get the userId from URL parameters
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    user: userId || '', // Automatically set user from URL param
    first_name: '',
    last_name: '',
    email: '',
    phone_number: '',
    profile_photo: null,
    roll_number: '',
    course: '',
    year_of_study: '',
    date_of_birth: '',
    address: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleFileChange = (e) => {
    setFormData({
      ...formData,
      profile_photo: e.target.files[0]
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log("Form data before appending to FormData:", formData);

    const data = new FormData();
    for (const key in formData) {
      data.append(key, formData[key]);
    }

    try {
      const response = await axios.post('http://127.0.0.1:8000/students/', data, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });
      alert('Student data saved successfully!');
      navigate(`/User-Dashboard/${userId}`);
    } catch (error) {
      console.error('Error saving student data:', error);
      console.log(data);
    }
  };

  return (
    <Box sx={{ maxWidth: 800, margin: '0 auto', padding: 3 }}>
      <Typography variant="h4" gutterBottom>Student Information Form</Typography>
      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              label="First Name"
              name="first_name"
              value={formData.first_name}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Last Name"
              name="last_name"
              value={formData.last_name}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Email"
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Phone Number"
              name="phone_number"
              value={formData.phone_number}
              onChange={handleChange}
              fullWidth
            />
          </Grid>
          <Grid item xs={12}>
            <Input
              type="file"
              name="profile_photo"
              onChange={handleFileChange}
              fullWidth
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Roll Number"
              name="roll_number"
              value={formData.roll_number}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Course"
              name="course"
              value={formData.course}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Year of Study"
              type="number"
              name="year_of_study"
              value={formData.year_of_study}
              onChange={handleChange}
              fullWidth
              required
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              label="Date of Birth"
              type="date"
              name="date_of_birth"
              value={formData.date_of_birth}
              onChange={handleChange}
              fullWidth
            />
          </Grid>
          <Grid item xs={12}>
            <TextField
              label="Address"
              name="address"
              value={formData.address}
              onChange={handleChange}
              fullWidth
              multiline
              rows={4}
            />
          </Grid>
        </Grid>
        <Button type="submit" variant="contained" color="primary" fullWidth sx={{ mt: 3 }}>
          Save Student
        </Button>
      </form>
    </Box>
  );
};

export default StudentForm;

