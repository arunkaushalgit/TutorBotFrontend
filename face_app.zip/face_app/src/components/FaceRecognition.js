import React, { useState, useRef, useEffect } from "react";
import axios from "axios";
import "./FaceRecognition.css"; // Add a CSS file for styling

const FaceRecognition = () => {
  const [countdown, setCountdown] = useState(null);
  const [response, setResponse] = useState(null);
  const videoRef = useRef(null);
  const canvasRef = useRef(null);

  const startVideo = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (err) {
      console.error("Error accessing webcam:", err);
      alert("Unable to access webcam. Please check your browser settings.");
    }
  };

  const startCapture = () => {
    if (!videoRef.current || !videoRef.current.srcObject) {
      alert("Camera is not started. Please click 'Start Camera' first.");
      return;
    }

    setCountdown(3); // Start countdown from 5 seconds
    const interval = setInterval(() => {
      setCountdown((prev) => {
        if (prev === 1) {
          clearInterval(interval);
          setCountdown(null);
          captureImage(); // Capture image when countdown ends
          return null;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const captureImage = () => {
    const video = videoRef.current;
    const canvas = canvasRef.current;

    if (!video || !canvas) {
      console.error("Video or canvas element is missing.");
      return;
    }

    const context = canvas.getContext("2d");
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;

    // Draw image in circular clip
    context.beginPath();
    const size = Math.min(canvas.width, canvas.height);
    context.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2, true);
    context.closePath();
    context.clip();
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Convert canvas to Blob
    canvas.toBlob(async (blob) => {
      const formData = new FormData();
      formData.append("image", blob, "captured_image.jpg");

      try {
        const res = await axios.post(
          "http://127.0.0.1:8000/api/face-recognition/",
          formData,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          }
        );
        setResponse(res.data);

        // Set a timer to clear the response after 3 minutes
        setTimeout(() => {
          setResponse(null);
        }, 6 * 1000); // 6 second visibilty
      } catch (err) {
        console.error("Error during face recognition request:", err);
        alert("Error detecting faces. Please try again.");
      }
    }, "image/jpeg");
  };

  return (
    <div className="face-recognition-container">
      <h1 className="title">Face Recognition</h1>
      <div className="button-container">
        <button className="btn start-btn" onClick={startVideo}>
          Start Camera
        </button>
        <button
          className="btn capture-btn"
          onClick={startCapture}
          disabled={countdown !== null}
        >
          Start Capture
        </button>
      </div>
      {countdown !== null && <h2 className="countdown">Time Remaining: {countdown}</h2>}
      <div className="video-container">
        <video ref={videoRef} className="video" />
        <canvas ref={canvasRef} className="hidden-canvas" />
      </div>
      {response && (
        <div className="response-container">
          <h2 className="recognized-name">{response.name}</h2>
          <h2 className="recognized-name">{response.status}</h2>
          {/* <pre className="response-details">{JSON.stringify(response, null, 2)}</pre> */}
        </div>
      )}
    </div>
  );
};

export default FaceRecognition;
