import React, { useState } from "react";
import { Link } from 'react-router-dom';

import axios from "axios";
import { TextField, Button, Typography, Container, Box, Paper } from "@mui/material";
// import backgroundImage from "../../images/background.jpg"; // Adjust path if needed
import { useNavigate } from 'react-router-dom';

const LoginPage = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        username: "",
        password: "",
    });

    const [message, setMessage] = useState("");
    const [error, setError] = useState("");

    const handleChange = (e) => {
        setFormData({
            ...formData,
            [e.target.name]: e.target.value,
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage("");
        setError("");

        try {
            const response = await axios.post("http://127.0.0.1:8000/api/signin/", formData);
            console.log(response.data.user_id);
            const { token, user_id } = response.data;

            // Save token and student_id in localStorage
            localStorage.setItem("token", token); // Store token
            localStorage.setItem("student_id", user_id); // Store student_id
            console.log("Login successful! token saved:", token);
            console.log("Login successful! Student ID saved:", user_id);
            
            if (response.data.success) {
                setMessage(response.data.massage);
                // navigate('/main-page/${response.data.id}');
                // navigate(`/student-form/${response.data.user_id}`);
                if (formData.username === "Admin") {
                    // Navigate to the Admin Dashboard if the username is "Admin"
                    navigate(`/Admin-Dashboard/${response.data.user_id}`);
                } else if (!response.data.first_name || response.data.first_name.trim() === "") {
                    console.log(response.data);
                    navigate(`/Add-Student/${response.data.user_id}`);
                } else {
                    // Navigate to Add-Student page for other users
                    console.log(response.data);
                    navigate(`/User-Dashboard/${response.data.user_id}`);
                    // localStorage.setItem("User_id", response.user_id);
                    // console.log("Login successful! Student ID saved:", response.user_id);

                }
                
                localStorage.setItem("token", response.data.token); // Save token to localStorage
            } else {
                setError(response.data.massage || "Login failed");
            }
        } catch (err) {
            if (err.response && err.response.data.massage) {
                setError(err.response.data.massage);
            } else {
                setError("An unexpected error occurred.");
            }
        }
    };

    return (
        <Box
            sx={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                minHeight: "100vh",
                // backgroundImage: `url(${backgroundImage})`,
                backgroundSize: "cover",
                backgroundPosition: "center",
                padding: 2,
            }}
        >
            <Container maxWidth="xs">
                <Paper elevation={3} sx={{ padding: 3, backgroundColor: "rgba(255, 255, 255, 0.9)" }}>
                    <Typography variant="h4" align="center" gutterBottom>
                        Signin
                    </Typography>
                    {message && <Typography color="success.main">{message}</Typography>}
                    {error && <Typography color="error.main">{error}</Typography>}
                    <form onSubmit={handleSubmit}>
                        <TextField
                            label="Username"
                            name="username"
                            value={formData.username}
                            onChange={handleChange}
                            fullWidth
                            margin="normal"
                            required
                        />
                        <TextField
                            label="Password"
                            name="password"
                            type="password"
                            value={formData.password}
                            onChange={handleChange}
                            fullWidth
                            margin="normal"
                            required
                        />
                        <Button
                            type="submit"
                            variant="contained"
                            color="primary"
                            fullWidth
                            sx={{ marginTop: 2 }}
                        >
                            Signin
                        </Button>
                    </form>
                    <Box mt={2} textAlign="center">
                    <Typography variant="body2">
                        Don't have an account?{' '}
                        <Link to="/sign-up" underline="hover">
                            Sign Up
                        </Link>
                    </Typography>
                    <Typography variant="body2" mt={1}>
                        <Link to="/forgot-password" underline="hover">
                            Forgot Password?
                        </Link>
                    </Typography>
                </Box>
                </Paper>
            </Container>
        </Box>
    );
};

export default LoginPage;



