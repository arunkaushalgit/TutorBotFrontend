import React, { useState, useEffect } from "react";
import {
  Container,
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Pagination,
  Avatar,
  CircularProgress,
} from "@mui/material";
import axios from "axios";

const PresentStudents = () => {
  const [data, setData] = useState([]); // Store student data
  const [loading, setLoading] = useState(true); // Loading state
  const [error, setError] = useState(null); // Error state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 2; // Number of students per page

  // Fetch data from API
  useEffect(() => {
    axios
      .get("http://127.0.0.1:8000/students/") // Replace with your API URL
      .then((response) => {
        // Filter data to include only students with "Present" status
        const presentStudents = response.data.filter((student) =>
          student.attendance?.some((att) => att.status === "Present")
        );
        setData(presentStudents);
        setLoading(false);
      })
      .catch((error) => {
        setError("Failed to fetch data.");
        setLoading(false);
      });
  }, []);

  // Calculate pagination
  const totalPages = Math.ceil(data.length / itemsPerPage);
  const currentData = data.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const handlePageChange = (event, value) => {
    setCurrentPage(value);
  };

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", marginTop: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Typography
        variant="h6"
        align="center"
        color="error"
        sx={{ marginTop: 5 }}
      >
        {error}
      </Typography>
    );
  }

  return (
    <Container sx={{ marginTop: 5 }}>
      <Box sx={{ padding: 3, backgroundColor: "#f5f5f5", borderRadius: 2 }}>
        <Typography variant="h4" align="center" gutterBottom>
          Present Students Details
        </Typography>
        {data.length === 0 ? (
          <Typography variant="body1" align="center" color="textSecondary">
            No present students found.
          </Typography>
        ) : (
          <>
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell align="center">Photo</TableCell>
                    <TableCell align="center">Name</TableCell>
                    <TableCell align="center">Email</TableCell>
                    <TableCell align="center">Roll Number</TableCell>
                    <TableCell align="center">Course</TableCell>
                    <TableCell align="center">Attendance</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentData.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell align="center">
                        {student.profile_photo ? (
                          <Avatar
                            src={student.profile_photo}
                            alt={student.first_name}
                          />
                        ) : (
                          <Avatar>{student.first_name[0]}</Avatar>
                        )}
                      </TableCell>
                      <TableCell align="center">
                        {student.first_name} {student.last_name}
                      </TableCell>
                      <TableCell align="center">{student.email}</TableCell>
                      <TableCell align="center">{student.roll_number}</TableCell>
                      <TableCell align="center">{student.course}</TableCell>
                      <TableCell align="center">
                        {student.attendance
                          ?.filter((att) => att.status === "Present")
                          .map((att) => (
                            <div key={att.id}>
                              {att.date}: {att.status}
                            </div>
                          ))}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Box sx={{ display: "flex", justifyContent: "center", marginTop: 3 }}>
              <Pagination
                count={totalPages}
                page={currentPage}
                onChange={handlePageChange}
                color="primary"
              />
            </Box>
          </>
        )}
      </Box>
    </Container>
  );
};

export default PresentStudents;
