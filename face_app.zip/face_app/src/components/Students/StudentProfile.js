import React, { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import {
  Box,
  Button,
  TextField,
  Typography,
  Avatar,
  Grid,
} from "@mui/material";

const StudentProfile = () => {
  const [student, setStudent] = useState({
    profile_photo: null,
    first_name: "",
    last_name: "",
    email: "",
    phone_number: "",
    roll_number: "",
    course: "",
    year_of_study: "",
    date_of_birth: "",
    address: "",
  });

  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const { studentId } = useParams(); // Fetch the user ID from URL parameters
  console.log("userId", studentId )

const API_URL = `http://127.0.0.1:8000/api/students/${studentId}/`;
//   const API_URL = `http://127.0.0.1:8000/api/students/6/`;

  // Fetch Student Data
  useEffect(() => {
    axios
      .get(API_URL)
      .then((res) => setStudent(res.data))
      .catch((err) => setError("Failed to load student data."));
  }, [API_URL]);

  // Handle Input Change
  const handleChange = (e) => {
    const { name, value } = e.target;
    setStudent({ ...student, [name]: value });
  };

  // Handle Image Upload
  const handleImageChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setStudent({ ...student, profile_photo: e.target.files[0] });
    }
  };

  // Handle Save Changes
  const handleSave = () => {
    const formData = new FormData();
    for (const key in student) {
      if (key === "profile_photo" && student[key] instanceof File) {
        formData.append(key, student[key]);
      } else if (key !== "profile_photo") {
        formData.append(key, student[key]);
      }
    }
  
    axios
      .put(API_URL, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      })
      .then((res) => {
        setStudent(res.data);
        setIsEditing(false);
      })
      .catch((err) => console.error(err.response.data));
  };
   
//   const handleSave = () => {
//     const formData = new FormData();
//     for (const key in student) {
//       if (key === "profile_photo" && student[key] instanceof File) {
//         formData.append(key, student[key]); // Attach file
//       } else {
//         formData.append(key, student[key]);
//       }
//     }

//     setLoading(true);
//     axios
//       .put(API_URL, formData, {
//         headers: { "Content-Type": "multipart/form-data" },
//       })
//       .then((res) => {
//         setStudent(res.data);
//         setIsEditing(false);
//         setError("");
//       })
//       .catch((err) => {
//         setError("Failed to save changes. Please try again.");
//         console.error(err.response?.data || err.message);
//       })
//       .finally(() => setLoading(false));
//   };

  return (
    <Box p={3} sx={{ maxWidth: 600, margin: "auto" }}>
      <Typography variant="h4" align="center" gutterBottom>
        Student Profile
      </Typography>
      {error && (
        <Typography color="error" align="center" gutterBottom>
          {error}
        </Typography>
      )}
      <Box display="flex" justifyContent="center" mb={2}>
        <Avatar
          src={
            student.profile_photo instanceof File
              ? URL.createObjectURL(student.profile_photo)
              : student.profile_photo
              ? `http://127.0.0.1:8000/${student.profile_photo}`
              : ""
          }
          sx={{ width: 120, height: 120 }}
        />
      </Box>

      {isEditing && (
        <Button variant="contained" component="label" fullWidth>
          Upload New Photo
          <input type="file" hidden onChange={handleImageChange} />
        </Button>
      )}

      <Grid container spacing={2} mt={1}>
        {[
          { label: "First Name", field: "first_name" },
          { label: "Last Name", field: "last_name" },
          { label: "Email", field: "email" },
          { label: "Phone Number", field: "phone_number" },
          { label: "Roll Number", field: "roll_number" },
          { label: "Course", field: "course" },
          { label: "Year of Study", field: "year_of_study" },
          { label: "Date of Birth", field: "date_of_birth" },
          { label: "Address", field: "address" },
        ].map(({ label, field }) => (
          <Grid item xs={12} key={field}>
            <TextField
              fullWidth
              label={label}
              name={field}
              value={student[field] || ""}
              onChange={handleChange}
              InputProps={{ readOnly: !isEditing }}
              multiline={field === "address"}
            />
          </Grid>
        ))}
      </Grid>

      <Box mt={3} display="flex" justifyContent="space-between">
        {isEditing ? (
          <>
            <Button
              variant="contained"
              color="success"
              onClick={handleSave}
              disabled={loading}
            >
              {loading ? "Saving..." : "Save Changes"}
            </Button>
            <Button
              variant="outlined"
              color="error"
              onClick={() => setIsEditing(false)}
              disabled={loading}
            >
              Cancel
            </Button>
          </>
        ) : (
          <Button
            variant="contained"
            color="primary"
            onClick={() => setIsEditing(true)}
          >
            Edit Profile
          </Button>
        )}
      </Box>
    </Box>
  );
};

export default StudentProfile;
