import React, { useState, useEffect } from "react";
import {
  Container,
  Typography,
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Pagination,
  Avatar,
  IconButton,
  CircularProgress,
  Dialog,
  DialogTitle,
  DialogContent,
} from "@mui/material";
import { Visibility, Edit, Delete } from "@mui/icons-material";
import axios from "axios";
import { useNavigate } from 'react-router-dom';



const TotalStudents = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [attendanceDialogOpen, setAttendanceDialogOpen] = useState(false);
  const navigate = useNavigate();

  const itemsPerPage = 5;

  useEffect(() => {
    axios
      .get("http://127.0.0.1:8000/students/") // Replace with your API endpoint
      .then((response) => {
        setData(response.data);
        setLoading(false);
      })
      .catch((error) => {
        setError("Failed to fetch data.");
        setLoading(false);
      });
  }, []);

  const handlePageChange = (event, value) => {
    setCurrentPage(value);
  };

  const handleViewAttendance = (student) => {
    setSelectedStudent(student);
    setAttendanceDialogOpen(true);
  };

  const handleCloseAttendanceDialog = () => {
    setAttendanceDialogOpen(false);
    setSelectedStudent(null);
  };

  const handleEditStudent = (studentId) => {
    navigate(`/student-profile/${studentId}`)
  };

  const handleDeleteStudent = (studentId) => {
    const confirm = window.confirm(
      `Are you sure you want to delete attendance for Student ID: ${studentId}?`
    );
    if (confirm) {
      // Call API to delete attendance (example below)
      axios
        .delete(`http://127.0.0.1:8000/api/students/${studentId}/`)
        .then(() => {
          alert("Student attendance deleted successfully.");
          setData(data.filter((student) => student.id !== studentId));
        })
        .catch(() => {
          alert("Failed to delete student attendance.");
        });
    }
  };

  const totalPages = Math.ceil(data.length / itemsPerPage);
  const currentData = data.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  if (loading) {
    return (
      <Box sx={{ display: "flex", justifyContent: "center", marginTop: 5 }}>
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Typography
        variant="h6"
        align="center"
        color="error"
        sx={{ marginTop: 5 }}
      >
        {error}
      </Typography>
    );
  }

  return (
    <Container sx={{ marginTop: 5 }}>
      <Box sx={{ padding: 3, backgroundColor: "#f5f5f5", borderRadius: 2 }}>
        <Typography variant="h4" align="center" gutterBottom>
          Total Students Details
        </Typography>
        {data.length === 0 ? (
          <Typography variant="body1" align="center" color="textSecondary">
            No students found.
          </Typography>
        ) : (
          <>
            <TableContainer component={Paper}>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell align="center">Photo</TableCell>
                    <TableCell align="center">Name</TableCell>
                    <TableCell align="center">Email</TableCell>
                    <TableCell align="center">Roll Number</TableCell>
                    <TableCell align="center">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {currentData.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell align="center">
                        {student.profile_photo ? (
                          <Avatar
                            src={student.profile_photo}
                            alt={`${student.first_name} ${student.last_name}`}
                          />
                        ) : (
                          <Avatar>{student.first_name[0]}</Avatar>
                        )}
                      </TableCell>
                      <TableCell align="center">
                        {student.first_name} {student.last_name}
                      </TableCell>
                      <TableCell align="center">{student.email}</TableCell>
                      <TableCell align="center">{student.roll_number}</TableCell>
                      <TableCell align="center">
                        <IconButton
                          onClick={() => handleViewAttendance(student)}
                          color="primary"
                        >
                          <Visibility />
                        </IconButton>
                        <IconButton
                          onClick={() => handleEditStudent(student.user)}
                          color="secondary"
                        >
                          <Edit />
                        </IconButton>
                        <IconButton
                          onClick={() => handleDeleteStudent(student.user)}
                          color="error"
                        >
                          <Delete />
                        </IconButton>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Box sx={{ display: "flex", justifyContent: "center", marginTop: 3 }}>
              <Pagination
                count={totalPages}
                page={currentPage}
                onChange={handlePageChange}
                color="primary"
              />
            </Box>
          </>
        )}
      </Box>

      {/* Dialog for Viewing Attendance */}
      <Dialog
        open={attendanceDialogOpen}
        onClose={handleCloseAttendanceDialog}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Attendance Details</DialogTitle>
        <DialogContent>
          {selectedStudent && (
            <Box>
              <Typography variant="h6">
                {selectedStudent.first_name} {selectedStudent.last_name}
              </Typography>
              {Array.isArray(selectedStudent.attendance) &&
                selectedStudent.attendance.map((att) => (
                  <Box key={att.id} sx={{ marginBottom: 2 }}>
                    <Typography>
                      <strong>Date:</strong> {att.date}
                    </Typography>
                    <Typography>
                      <strong>Status:</strong> {att.status}
                    </Typography>
                    <Typography>
                      <strong>Time In:</strong> {att.time_in}
                    </Typography>
                    <Typography>
                      <strong>Time Out:</strong> {att.time_out}
                    </Typography>
                    <Typography>
                      <strong>Present Time:</strong>{" "}
                      {att.total_time_present} mins
                    </Typography>
                    <Typography>
                      <strong>Absent Time:</strong> {att.total_time_absent} mins
                    </Typography>
                  </Box>
                ))}
            </Box>
          )}
        </DialogContent>
      </Dialog>
    </Container>
  );
};

export default TotalStudents;
