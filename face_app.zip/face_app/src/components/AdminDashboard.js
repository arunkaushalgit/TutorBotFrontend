import React, { useEffect, useState } from "react";
import { 
  Container, 
  Grid, 
  Card, 
  CardContent, 
  Typography, 
  Box, 
  Button 
} from "@mui/material";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import AdminNavbar from "./AdminNavbar";

const AdminDashboard = () => {
  const [totalStudents, setTotalStudents] = useState(0);
  const [presentStudents, setPresentStudents] = useState(0);
  const [absentStudents, setAbsentStudents] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    axios
      .get("http://127.0.0.1:8000/students") // Replace with the correct API endpoint
      .then((response) => {
        const students = response.data;
        setTotalStudents(students.length);

        const presentCount = students.filter((student) =>
          student.attendance.some((attendance) => attendance.status === "Present")
        ).length;

        const absentCount = students.filter((student) =>
          student.attendance.some((attendance) => attendance.status === "Absent")
        ).length;

        setPresentStudents(presentCount);
        setAbsentStudents(absentCount);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);

  const handleNavigate = (path) => {
    navigate(path);
  };

  return (
    <>
    <AdminNavbar/> 
    <Container maxWidth="lg" sx={{ marginTop: 5, paddingBottom: 5 }}>
      <Typography variant="h4" align="center" gutterBottom>
        Admin Dashboard
      </Typography>
      <Grid container spacing={4} justifyContent="center">
        {[
          {
            label: "Total Students",
            value: totalStudents,
            color: "#3f51b5",
            path: "/total-students",
          },
          {
            label: "Present Students",
            value: presentStudents,
            color: "#4caf50",
            path: "/present-students",
          },
          {
            label: "Absent Students",
            value: absentStudents,
            color: "#f44336",
            path: "/absent-students",
          },
        ].map((card, index) => (
          <Grid item xs={12} sm={6} md={4} key={index}>
            <Card
              sx={{
                cursor: "pointer",
                boxShadow: 4,
                transition: "transform 0.3s",
                "&:hover": {
                  transform: "scale(1.05)",
                },
              }}
              onClick={() => handleNavigate(card.path)}
            >
              <CardContent>
                <Typography variant="h6" align="center">
                  {card.label}
                </Typography>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    alignItems: "center",
                    height: "100px",
                    backgroundColor: card.color,
                    color: "white",
                    borderRadius: "10px",
                    marginTop: 2,
                  }}
                >
                  <Typography variant="h3">{card.value}</Typography>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
      <Grid container spacing={4} justifyContent="center" marginTop={5}>
        <Grid item xs={12} sm={6}>
          <Card
            sx={{
              boxShadow: 4,
              padding: 3,
              textAlign: "center",
            }}
          >
            <Typography variant="h5" gutterBottom>
              Add Student
            </Typography>
            <Button variant="contained" color="primary" onClick={() => navigate("/sign-up")}>
              Add Student
            </Button>
          </Card>
        </Grid>
        <Grid item xs={12} sm={6}>
          <Card
            sx={{
              boxShadow: 4,
              padding: 3,
              textAlign: "center",
            }}
          >
            <Typography variant="h5" gutterBottom>
              Open Camera
            </Typography>
            <Button variant="contained" color="primary" onClick={() => navigate("/camera")}>
              Open Camera
            </Button>
          </Card>
        </Grid>
      </Grid>
    </Container>
    </>
  );
};

export default AdminDashboard;
