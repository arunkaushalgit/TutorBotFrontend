import React, { useState, useEffect } from 'react';
import { Container, TextField, Button, Typography, Box, Alert } from '@mui/material';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';

const SendOtpPage = () => {
    const navigate = useNavigate();
    const { email } = useParams(); // Retrieve email from URL
    const [otp, setOtp] = useState('');
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');

    // Log email to verify it's being passed correctly
    console.log('Received email:', email);

    const handleOtpChange = (e) => {
        setOtp(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError('');
        setSuccess('');

        // Check if email is passed properly
        if (!email) {
            setError('Email is missing. Please ensure email is passed correctly.');
            return;
        }

        try {
            // Sending the OTP verification request to the backend
            const response = await axios.post('http://127.0.0.1:8000/api/verify-otp/', {
                email: email,  // Pass the email associated with OTP
                otp: otp,
            });

            // Check if the response status indicates success
            if (response.status === 201) {
                console.log(response.data.user_id);
                
                setSuccess('OTP verified successfully! User created. Redirecting...');
                setTimeout(() => {
                    navigate(`/Add-student/${response.data.user_id}`);
                }, 2000); // Redirect after 2 seconds
            }
        } catch (err) {
            if (err.response) {
                // Handle error returned by the backend
                setError(err.response.data.error || 'Invalid OTP. Please try again.');
            } else {
                // Handle general error like network issues
                setError('Unable to connect to the server. Please try again later.');
            }
        }
    };

    return (
        <Container maxWidth="sm">
            <Box sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', marginTop: 4, padding: 4, boxShadow: 3, borderRadius: 2 }}>
                <Typography variant="h5" component="h2" gutterBottom>
                    Verify Your OTP
                </Typography>
                <Typography variant="body1" color="textSecondary" gutterBottom>
                    Enter the OTP sent to your registered email: <strong>{email}</strong>.
                </Typography>
                <form onSubmit={handleSubmit} style={{ width: '100%' }}>
                    <TextField
                        label="Enter OTP"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="otp"
                        value={otp}
                        onChange={handleOtpChange}
                        required
                    />
                    {error && <Alert severity="error" sx={{ marginY: 2 }}>{error}</Alert>}
                    {success && <Alert severity="success" sx={{ marginY: 2 }}>{success}</Alert>}
                    <Button
                        type="submit"
                        variant="contained"
                        color="primary"
                        fullWidth
                        sx={{ marginTop: 2 }}
                    >
                        Verify OTP
                    </Button>
                </form>
            </Box>
        </Container>
    );
};

export default SendOtpPage;





