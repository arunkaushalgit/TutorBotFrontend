



import React, { useState } from 'react';
import axios from 'axios';
import { Container, TextField, Button, Typography, Box, Link, Alert } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const SignupPage = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState({
        username: '',
        email: '',
        password: '',
        confirmpassword: ''
    });
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [loading, setLoading] = useState(false);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value
        });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (formData.password !== formData.confirmpassword) {
            setError('Passwords do not match');
            return;
        }

        setError('');
        setSuccess('');
        setLoading(true);

        try {
            const response = await axios.post('http://127.0.0.1:8000/api/signup/', {
                username: formData.username,
                email: formData.email,
                password: formData.password,
                confirm_password: formData.confirmpassword
            });

            if (response.status === 201 || response.status === 200) {
                setSuccess('Registration successful! OTP will be sent to your email.');
                setTimeout(() => {
                    navigate(`/otp-page/${formData.email}`);
                }, 2000);
            } else {
                setError('Something went wrong. Please try again.');
            }
        } catch (error) {
            if (error.response && error.response.data) {
                setError(typeof error.response.data.error === 'string' ? error.response.data.error : 'Registration failed. Please try again.');
            } else {
                setError('An error occurred. Please try again.');
            }
        } finally {
            setLoading(false);
        }
    };

    return (
        <Container maxWidth="sm">
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    marginTop: 4,
                    padding: 4,
                    boxShadow: 3,
                    borderRadius: 2
                }}
            >
                <Typography variant="h4" component="h1" gutterBottom>
                    Sign Up
                </Typography>
                <form onSubmit={handleSubmit} style={{ width: '100%' }}>
                    <TextField
                        label="Username"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="username"
                        value={formData.username}
                        onChange={handleChange}
                        required
                    />
                    <TextField
                        label="Email"
                        type="email"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                    <TextField
                        label="Password"
                        type="password"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                    <TextField
                        label="Confirm Password"
                        type="password"
                        variant="outlined"
                        fullWidth
                        margin="normal"
                        name="confirmpassword"
                        value={formData.confirmpassword}
                        onChange={handleChange}
                        required
                    />
                    {error && (
                        <Alert severity="error" sx={{ marginTop: 2 }}>
                            {typeof error === 'string' ? error : JSON.stringify(error)}
                        </Alert>
                    )}
                    {success && (
                        <Alert severity="success" sx={{ marginTop: 2 }}>
                            {success}
                        </Alert>
                    )}
                    <Button
                        type="submit"
                        variant="contained"
                        color="primary"
                        fullWidth
                        sx={{ marginTop: 2 }}
                        disabled={loading}
                    >
                        {loading ? 'Signing Up...' : 'Sign Up'}
                    </Button>
                </form>
                <Box mt={2} textAlign="center">
                    <Typography variant="body2">
                        Already have an account?{' '}
                        <Link component="button" onClick={() => navigate('/')} underline="hover">
                            Sign In
                        </Link>
                    </Typography>
                </Box>
            </Box>
        </Container>
    );
};

export default SignupPage;

