import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Container,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Typography,
  CircularProgress,
} from '@mui/material';
import UserNavbar from '../components/UserNavbar';

const AwsQuizResults = () => {
  const [quizResults, setQuizResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Fetch data from the API
    axios
      .get('http://127.0.0.1:8000/api/aws-quiz-scores/ ') // Replace with your API endpoint
      .then((response) => {
        setQuizResults(response.data);
        setLoading(false);
      })
      .catch((error) => {
        console.error('Error fetching quiz scores:', error);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <Container style={{ textAlign: 'center', marginTop: '20px' }}>
        <CircularProgress />
      </Container>
    );
  }

  return (
  <>
  <UserNavbar/>
    <Container style={{ marginTop: '20px' }}>
      <Typography variant="h4" gutterBottom>
        AWS Quiz Results
      </Typography>
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell><strong>User</strong></TableCell>
              <TableCell align="center"><strong>Score</strong></TableCell>
              <TableCell align="center"><strong>Correct Answers</strong></TableCell>
              <TableCell align="center"><strong>Wrong Answers</strong></TableCell>
              <TableCell align="center"><strong>Not Attempted</strong></TableCell>
              <TableCell align="center"><strong>Attempt Date</strong></TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {quizResults.map((result) => (
              <TableRow key={result.id}>
                <TableCell>{result.user.username}</TableCell>
                <TableCell align="center">{result.score}</TableCell>
                <TableCell align="center">{result.correct_answers}</TableCell>
                <TableCell align="center">{result.wrong_answers}</TableCell>
                <TableCell align="center">{result.not_attempted}</TableCell>
                <TableCell align="center">{result.attempt_date}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>
    </Container>
    </>
  );
};

export default AwsQuizResults;
