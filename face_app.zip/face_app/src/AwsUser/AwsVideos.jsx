import React, { useState, useEffect } from 'react';
import { Modal, Card, CardMedia, CardContent, Grid, Box, Typography, Button } from '@mui/material';
import axios from 'axios';
import UserNavbar from '../components/UserNavbar';


const AwsVideos = () => {
  const [open, setOpen] = useState(false);
  const [currentVideo, setCurrentVideo] = useState(null);
  const [videos, setVideos] = useState([]);

  // Fetch video data from the API
  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/api/aws-video/');
        setVideos(response.data); // Set videos in state
      } catch (error) {
        console.error('Error fetching videos:', error);
      }
    };
    fetchVideos();
  }, []);

  const handleOpen = (video) => {
    setCurrentVideo(video);
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setCurrentVideo(null);
  };

  return (
    <>
    <UserNavbar/>
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" textAlign="center" gutterBottom>
        Video Gallery
      </Typography>

      <Grid container spacing={2}>
        {videos.map((video) => (
          <Grid item xs={12} sm={6} md={4} key={video.id}>
            <Card
              sx={{
                boxShadow: 3,
                ':hover': { boxShadow: 6 },
                cursor: 'pointer',
              }}
              onClick={() => handleOpen(video)}
            >
              <CardMedia
                component="img"
                height="200"
                image={`http://127.0.0.1:8000${video.image}`} // Assuming the image URL is relative
                alt={video.title}
              />
              <CardContent>
                <Typography variant="h6" gutterBottom>
                  {video.title}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Modal open={open} onClose={handleClose}>
        <Box
          sx={{
            position: 'absolute',
            top: '50%',
            left: '50%',
            transform: 'translate(-50%, -50%)',
            width: '80%',
            bgcolor: 'background.paper',
            boxShadow: 24,
            p: 4,
            borderRadius: 2,
          }}
        >
          {currentVideo && (
            <>
              <Typography variant="h5" gutterBottom>
                {currentVideo.title}
              </Typography>
              <Box sx={{ position: 'relative', paddingTop: '56.25%' }}>
                <iframe
                  width="100%"
                  height="100%"
                  src={currentVideo.url}
                  title={currentVideo.title}
                  frameBorder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                  style={{
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    width: '100%',
                    height: '100%',
                  }}
                ></iframe>
              </Box>
              <Button onClick={handleClose} variant="contained" color="primary" sx={{ mt: 2 }}>
                Close
              </Button>
            </>
          )}
        </Box>
      </Modal>
    </Box>
    </>
  );
};

export default AwsVideos;


