import React, { useEffect, useState } from "react";
import Stack from "@mui/material/Stack";
import Button from "@mui/material/Button";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { styled } from "@mui/system";
import CircularProgress from "@mui/material/CircularProgress";
import Divider from "@mui/material/Divider";
import UserNavbar from "../components/UserNavbar";
// import MainPage from "../components/Login/MainPage";

const StyledContainer = styled(Box)(({ theme }) => ({
    maxWidth: "1400px",
    margin: "auto",
    padding: theme.spacing(3),
    textAlign: "center",
    backgroundColor: "#f9f9f9",
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
    borderRadius: theme.shape.borderRadius,
}));

const ChatBox = styled(Box)(({ theme }) => ({
    maxHeight: "400px",
    overflowY: "auto",
    padding: theme.spacing(2),
    marginTop: theme.spacing(2),
    backgroundColor: "#e8f5e9",
    borderRadius: theme.shape.borderRadius,
    boxShadow: "0px 2px 4px rgba(0, 0, 0, 0.1)",
}));

const StyledMessage = styled(Box)(({ theme }) => ({
    margin: theme.spacing(1, 0),
    padding: theme.spacing(1.5),
    borderRadius: theme.shape.borderRadius,
    backgroundColor: "#fff",
    boxShadow: "0px 1px 3px rgba(0, 0, 0, 0.1)",
    textAlign: "left",
}));

const UserMessage = styled(StyledMessage)(({ theme }) => ({
    backgroundColor: "#d1c4e9",
    alignSelf: "flex-end",
}));

const AIMessage = styled(StyledMessage)(({ theme }) => ({
    // backgroundColor: "#bbdefb",
    alignSelf: "flex-start",
}));

const StyledButton = styled(Button)(({ theme }) => ({
    [theme.breakpoints.down("sm")]: {
        fontSize: "0.8rem",
    },
}));


const AwsQuestion = () => {
    
    
    const [subtopics, setSubtopics] = useState([]);
    const [currentIndex, setCurrentIndex] = useState(0);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [response, setResponse] = useState([]);
    const [isSending, setIsSending] = useState(false);
    const [showAnswer, setShowAnswer] = useState(false);

    useEffect(() => {
        fetch("http://127.0.0.1:8000/api/aws")
            .then((response) => {
                if (!response.ok) {
                    throw new Error("Failed to fetch data");
                }
                return response.json();
            })
            .then((data) => {
                setSubtopics(data || []);
                setLoading(false);
            })
            .catch((error) => {
                setError(error.message);
                setLoading(false);
            });
    }, []);

    const handleNext = () => {
        setShowAnswer(false);
        setCurrentIndex((prevIndex) =>
            prevIndex + 1 < subtopics.length ? prevIndex + 1 : prevIndex
        );
    };

    const handlePrevious = () => {
        setShowAnswer(false);
        setCurrentIndex((prevIndex) =>
            prevIndex - 1 >= 0 ? prevIndex - 1 : prevIndex
        );
    };

    const handleSendMessage = async () => {
        if (!subtopics[currentIndex]) {
            setResponse((prev) => [
                ...prev,
                { type: "ai", text: "No subtopic available to send." },
            ]);
            return;
        }

        setIsSending(true);

        try {
            const payload = {
                message: `Explain: ${subtopics[currentIndex].question}`,
            };
            const res = await fetch("http://127.0.0.1:8000/api/chat-completion/", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(payload),
            });

            if (!res.ok) {
                const errorDetails = await res.json();
                throw new Error(errorDetails.error || "Failed to get AI response");
            }

            const data = await res.json();
            if (data.response) {
                // Check if response is JSON or text
                let formattedResponse = data.response;
                try {
                    const jsonResponse = JSON.parse(data.response);
                    formattedResponse = (
                        <pre style={{ textAlign: "left", whiteSpace: "pre-wrap" }}>
                            {JSON.stringify(jsonResponse, null, 2)}
                        </pre>
                    );
                } catch {
                    formattedResponse = (
                        <p style={{ textAlign: "left", whiteSpace: "pre-wrap" }}>
                            {data.response}
                        </p>
                    );
                }

                setResponse((prev) => [...prev, { type: "ai", text: formattedResponse }]);
            } else {
                setResponse((prev) => [
                    ...prev,
                    { type: "ai", text: "Error: " + (data.error || "Unknown error") },
                ]);
            }
        } catch (err) {
            setResponse((prev) => [
                ...prev,
                { type: "ai", text: "An error occurred while fetching AI response" },
            ]);
        } finally {
            setIsSending(false);
        }
    };

    if (loading) return <Typography>Loading...</Typography>;
    if (error) return <Typography color="error">Error: {error}</Typography>;

    return (
        <>
        <UserNavbar/>
        {/* <MainPage/> */}
            <StyledContainer>
                <Typography variant="h4" gutterBottom>
                    AWS Learning Bot
                </Typography>
                <Box mb={2}>
                    {subtopics.length > 0 ? (
                        <>
                            <Typography variant="h6" gutterBottom>
                                Question: {subtopics[currentIndex]?.question}
                            </Typography>
                            {!showAnswer && (
                                <StyledButton
                                    variant="contained"
                                    color="primary"
                                    onClick={() => setShowAnswer(true)}
                                >
                                    Show Answer
                                </StyledButton>
                            )}
                            {showAnswer && (
                                <Typography variant="body1" mt={2}>
                                    Answer: {subtopics[currentIndex]?.answer}
                                </Typography>
                            )}
                        </>
                    ) : (
                        <Typography>No subtopics available.</Typography>
                    )}
                </Box>
                <Divider />
                <ChatBox>
                    {response.map((msg, index) => (
                        <Box key={index}>
                            {msg.type === "user" ? (
                                <UserMessage>{msg.text}</UserMessage>
                            ) : (
                                <AIMessage>{msg.text}</AIMessage>
                            )}
                        </Box>
                    ))}
                </ChatBox>
                <Stack direction="row" spacing={2} mt={2} justifyContent="center">
                    <StyledButton
                        variant="contained"
                        onClick={handlePrevious}
                        disabled={currentIndex === 0}
                    >
                        Previous
                    </StyledButton>
                    <StyledButton variant="contained" onClick={handleSendMessage}>
                        {isSending ? <CircularProgress size={20} /> : "AI Answer"}
                    </StyledButton>
                    <StyledButton
                        variant="contained"
                        onClick={handleNext}
                        disabled={currentIndex === subtopics.length - 1}
                    >
                        Next
                    </StyledButton>
                </Stack>
            </StyledContainer>
        </>
    );
   
};

export default AwsQuestion;
