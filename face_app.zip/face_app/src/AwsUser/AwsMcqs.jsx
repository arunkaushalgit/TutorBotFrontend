import React, { useState, useEffect } from "react";
import {
  Container,
  Typography,
  Button,
  Box,
  FormControl,
  FormLabel,
  RadioGroup,
  FormControlLabel,
  Radio,
  Snackbar,
  Alert,
} from "@mui/material";
import axios from "axios";
import UserNavbar from "../components/UserNavbar";
import { useNavigate } from "react-router-dom";

const AwsMcqs = () => {
  const [questions, setQuestions] = useState([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [timer, setTimer] = useState(15);
  const [success, setSuccess] = useState(false);
  const navigate = useNavigate();

  // Fetch questions from the backend
  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/aws-mcqs-get/");
        setQuestions(response.data);
      } catch (error) {
        console.error("Error fetching questions:", error);
      }
    };

    fetchQuestions();
  }, []);

  // Timer logic
  useEffect(() => {
    const interval = setInterval(() => {
      setTimer((prev) => {
        if (prev === 1) {
          handleNext();
          return 15; // Reset timer for the next question
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval); // Cleanup timer on component unmount
  }, [currentQuestionIndex]);

  // Handle answer change
  const handleAnswerChange = (value) => {
    setQuestions((prevQuestions) =>
      prevQuestions.map((q, index) =>
        index === currentQuestionIndex ? { ...q, answer: value } : q
      )
    );
  };

  // Navigate to the previous question
  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex((prev) => prev - 1);
      setTimer(15); // Reset timer for the previous question
    }
  };

  // Navigate to the next question
  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setTimer(15); // Reset timer for the next question
    } else {
      handleSubmit(); // Submit when all questions are completed
    }
  };

  // Submit answers to the backend
  const handleSubmit = async () => {
    const studentId = localStorage.getItem("student_id");

    if (!studentId) {
      alert("Student ID not found. Please log in again.");
      return;
    }

    const payload = questions.map((q) => ({
      id: q.id,
      student_id: studentId,
      answer: q.answer || null, // Ensure an answer is provided
    }));

    try {
      const response = await axios.post("http://127.0.0.1:8000/api/Aws-mcq/", payload);
      if (response.status === 200) {
        setSuccess(true);
        navigate(`/Aws-Mcqs-result/${studentId}`);
      }
    } catch (error) {
      console.error("Error submitting MCQs:", error);
      alert("An error occurred while submitting your answers. Please try again.");
    }
  };

  const currentQuestion = questions[currentQuestionIndex];

  return (
    <>
      <UserNavbar />
      <Container maxWidth="sm" style={{ marginTop: "2rem" }}>
        <Typography variant="h4" align="center" gutterBottom>
          MCQ Quiz
        </Typography>

        {currentQuestion ? (
          <Box
            mb={3}
            p={2}
            border={1}
            borderRadius={2}
            borderColor="grey.300"
            boxShadow={2}
          >
            <Typography variant="h6" gutterBottom>
              Question {currentQuestionIndex + 1}/{questions.length}
            </Typography>
            <Typography variant="h6" gutterBottom>
              {currentQuestion.question_text}
            </Typography>
            <FormControl component="fieldset">
              <FormLabel component="legend">Choose your answer</FormLabel>
              <RadioGroup
                value={currentQuestion.answer || ""}
                onChange={(e) => handleAnswerChange(e.target.value)}
              >
                {currentQuestion.options.map((option, index) => (
                  <FormControlLabel
                    key={index}
                    value={option}
                    control={<Radio />}
                    label={option}
                  />
                ))}
              </RadioGroup>
            </FormControl>
          </Box>
        ) : (
          <Typography variant="h6" align="center">
            Loading questions...
          </Typography>
        )}

        <Box display="flex" justifyContent="space-between" mt={2}>
          <Button
            variant="contained"
            color="secondary"
            disabled={currentQuestionIndex === 0}
            onClick={handlePrevious}
          >
            Previous
          </Button>
          <Typography variant="h6" align="center">
            Timer: {timer}s
          </Typography>
          <Button
            variant="contained"
            color="primary"
            onClick={handleNext}
          >
            {currentQuestionIndex === questions.length - 1
              ? "Submit"
              : "Next"}
          </Button>
        </Box>

        <Snackbar
          open={success}
          autoHideDuration={3000}
          onClose={() => setSuccess(false)}
        >
          <Alert severity="success" onClose={() => setSuccess(false)}>
            MCQs submitted successfully!
          </Alert>
        </Snackbar>
      </Container>
    </>
  );
};

export default AwsMcqs;
