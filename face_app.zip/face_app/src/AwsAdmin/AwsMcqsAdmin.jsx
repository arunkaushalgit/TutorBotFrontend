import React, { useState, useEffect } from "react";
import {
  Container,
  Typography,
  TextField,
  Button,
  Box,
  IconButton,
  Grid,
  Pagination,
  Input,
} from "@mui/material";
import { Edit, Delete } from "@mui/icons-material";
import axios from "axios";
import AdminNavbar from "../components/AdminNavbar";

const AwsMcqsAdmin = () => {
  const [questions, setQuestions] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [question, setQuestion] = useState("");
  const [options, setOptions] = useState(["", "", "", ""]);
  const [correctAnswer, setCorrectAnswer] = useState("");
  const [editingQuestionId, setEditingQuestionId] = useState(null);
  const [file, setFile] = useState(null);
  const itemsPerPage = 5;

  useEffect(() => {
    const fetchQuestions = async () => {
      try {
        const response = await axios.get("http://127.0.0.1:8000/api/aws-mcqs-get/");
        setQuestions(response.data);
        setTotalPages(Math.ceil(response.data.length / itemsPerPage));
      } catch (error) {
        console.error("Error fetching questions:", error);
      }
    };

    fetchQuestions();
  }, []);

  const getCurrentPageQuestions = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return questions.slice(startIndex, startIndex + itemsPerPage);
  };

  const handleAddOrEditQuestion = async (e) => {
    e.preventDefault();
    if (!question || options.some((opt) => !opt) || !correctAnswer) {
      alert("All fields, including options and correct answer, must be filled!");
      return;
    }

    try {
      if (editingQuestionId) {
        const response = await axios.put(
          `http://127.0.0.1:8000/api/aws-mcqs-update/${editingQuestionId}/`,
          { question_text: question, options, correct_answer: correctAnswer }
        );
        setQuestions((prev) =>
          prev.map((q) =>
            q.id === editingQuestionId ? response.data : q
          )
        );
        setEditingQuestionId(null);
      } else {
        const response = await axios.post(
          "http://127.0.0.1:8000/api/aws-mcqs-add/",
          { question_text: question, options, correct_answer: correctAnswer }
        );
        setQuestions((prev) => [...prev, response.data]);
        setTotalPages(Math.ceil((questions.length + 1) / itemsPerPage));
      }

      setQuestion("");
      setOptions(["", "", "", ""]);
      setCorrectAnswer("");
    } catch (error) {
      console.error("Error saving question:", error);
      alert("Failed to save question.");
    }
  };

  const handleEdit = (question) => {
    setEditingQuestionId(question.id);
    setQuestion(question.question_text);
    setOptions(question.options);
    setCorrectAnswer(question.correct_answer);
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://127.0.0.1:8000/api/aws-mcqs-delete/${id}/`);
      setQuestions((prev) => prev.filter((q) => q.id !== id));
      setTotalPages(Math.ceil((questions.length - 1) / itemsPerPage));
    } catch (error) {
      console.error("Error deleting question:", error);
    }
  };

  const handleFileSelection = (e) => {
    setFile(e.target.files[0]);
  };
  const handleFileUpload = async () => {
    if (!file) {
      alert("Please select a file to upload.");
      return;
    }
  
    const formData = new FormData();
    formData.append("file", file);
  
    try {
      const response = await axios.post(
        "http://127.0.0.1:8000/api/aws-mcqs-upload/",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );
  
      console.log("Uploaded data response:", response.data); // Debugging
  
      if (response.data.uploaded_questions && Array.isArray(response.data.uploaded_questions)) {
        // If the backend provides an array of uploaded questions
        setQuestions((prev) => [...prev, ...response.data.uploaded_questions]);
        setTotalPages(Math.ceil((questions.length + response.data.uploaded_questions.length) / itemsPerPage));
      } else {
        console.error("Error: Uploaded data does not contain an array of questions.", response.data);
  
        // Optional: Re-fetch all questions as a fallback
        const fetchResponse = await axios.get("http://127.0.0.1:8000/api/aws-mcqs-get/");
        if (Array.isArray(fetchResponse.data)) {
          setQuestions(fetchResponse.data);
          alert("Questions uploaded successfully!");
          setTotalPages(Math.ceil(fetchResponse.data.length / itemsPerPage));
        }
      }
    } catch (error) {
      console.error("Error uploading file:", error);
      alert("Failed to upload questions. Please try again.");
    }
  };
  

  // const handleFileUpload = async () => {
  //   if (!file) {
  //     alert("Please select a file to upload.");
  //     return;
  //   }

  //   const formData = new FormData();
  //   formData.append("file", file);

  //   try {
  //     const response = await axios.post(
  //       "http://127.0.0.1:8000/api/aws-mcqs-upload/",
  //       formData,
  //       {
  //         headers: {
  //           "Content-Type": "multipart/form-data",
  //         },
  //       }
  //     );
  //     alert(response.data.message || "Questions uploaded successfully!");
  //     setFile(null);
  //     setQuestions((prev) => [...prev, ...response.data]);
  //     setTotalPages(Math.ceil((questions.length + response.data.length) / itemsPerPage));
  //   } catch (error) {
  //     console.error("Error uploading file:", error);
  //     alert("Failed to upload questions.");
  //   }
  // };

  return (
    <>
      <AdminNavbar />
      <Container maxWidth="md" style={{ marginTop: "2rem" }}>
        <Typography variant="h4" align="center" gutterBottom>
          AWS MCQs Admin Panel
        </Typography>

        <Box component="form" onSubmit={handleAddOrEditQuestion} mt={4}>
          <Typography variant="h5" gutterBottom>
            {editingQuestionId ? "Edit Question" : "Add New Question"}
          </Typography>
          <TextField
            fullWidth
            label="Question Text"
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            margin="normal"
          />
          {options.map((option, index) => (
            <TextField
              key={index}
              fullWidth
              label={`Option ${index + 1}`}
              value={option}
              onChange={(e) => {
                const updatedOptions = [...options];
                updatedOptions[index] = e.target.value;
                setOptions(updatedOptions);
              }}
              margin="normal"
            />
          ))}
          <TextField
            fullWidth
            label="Correct Answer"
            value={correctAnswer}
            onChange={(e) => setCorrectAnswer(e.target.value)}
            margin="normal"
          />
          <Button
            variant="contained"
            color="primary"
            type="submit"
            style={{ marginTop: "1rem" }}
          >
            {editingQuestionId ? "Update Question" : "Add Question"}
          </Button>
        </Box>

        <Box mt={4}>
          <Typography variant="h5" gutterBottom>
            Upload Questions via Excel
          </Typography>
          <Input type="file" accept=".xlsx, .xls" onChange={handleFileSelection} />
          <Button
            variant="contained"
            color="primary"
            onClick={handleFileUpload}
            disabled={!file}
            style={{ marginTop: "1rem" }}
          >
            Upload Questions
          </Button>
        </Box>

        <Box mt={4}>
          <Typography variant="h5" gutterBottom>
            All Questions
          </Typography>
          {getCurrentPageQuestions().map((q) => (
            <Box
              key={q.id}
              p={2}
              mb={2}
              border={1}
              borderColor="grey.300"
              borderRadius={2}
              boxShadow={2}
            >
              <Grid container alignItems="center">
                <Grid item xs={10}>
                  <Typography variant="h6">{q.question_text}</Typography>
                </Grid>
                <Grid item xs={2}>
                  <IconButton
                    color="primary"
                    onClick={() => handleEdit(q)}
                    aria-label="edit"
                  >
                    <Edit />
                  </IconButton>
                  <IconButton
                    color="secondary"
                    onClick={() => handleDelete(q.id)}
                    aria-label="delete"
                  >
                    <Delete />
                  </IconButton>
                </Grid>
              </Grid>
            </Box>
          ))}

          <Box mt={2} display="flex" justifyContent="center">
            <Pagination
              count={totalPages}
              page={currentPage}
              onChange={(e, page) => setCurrentPage(page)}
            />
          </Box>
        </Box>
      </Container>
    </>
  );
};

export default AwsMcqsAdmin;
