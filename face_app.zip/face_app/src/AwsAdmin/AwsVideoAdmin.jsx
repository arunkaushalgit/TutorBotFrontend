import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Box, Button, TextField, Typography, Alert, Card, CardMedia, CardContent, CardActions } from '@mui/material';
import { styled } from '@mui/system';
import AdminNavbar from '../components/AdminNavbar';
// import Navbar from './Navbar';

const StyledForm = styled('form')({
    display: 'flex',
    flexDirection: 'column',
    gap: '20px',
    width: '100%',
    maxWidth: '500px',
    margin: 'auto',
    padding: '20px',
    borderRadius: '8px',
    boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
    backgroundColor: '#f9f9f9',
});

const AwsVideoAdmin = () => {
    const [title, setTitle] = useState('');
    const [url, setUrl] = useState('');
    const [image, setImage] = useState(null);
    const [message, setMessage] = useState('');
    const [videos, setVideos] = useState([]);
    const [editVideoId, setEditVideoId] = useState(null);  // For tracking which video is being edited

    // Fetch videos from the backend
    const fetchVideos = async () => {
        try {
            const response = await axios.get('http://127.0.0.1:8000/api/aws-video/');
            setVideos(response.data);
        } catch (error) {
            console.error('Failed to fetch videos:', error);
        }
    };

    useEffect(() => {
        fetchVideos();
    }, []);

    const handleSubmit = async (e) => {
        e.preventDefault();

        const formData = new FormData();
        formData.append('title', title);
        formData.append('url', url);
        if (image) {
            formData.append('image', image);
        }

        const endpoint = editVideoId
            ? `http://127.0.0.1:8000/api/aws-video/${editVideoId}/`
            : 'http://127.0.0.1:8000/api/aws-video/';

        const method = editVideoId ? 'put' : 'post';

        try {
            const response = await axios({
                method,
                url: endpoint,
                data: formData,
                headers: {
                    'Content-Type': 'multipart/form-data',
                },
            });
            setMessage(editVideoId ? 'Video updated successfully!' : 'Video uploaded successfully!');
            fetchVideos(); // Refresh the video list after upload/update
            setTitle('');
            setUrl('');
            setImage(null);
            setEditVideoId(null); // Reset editing state
        } catch (error) {
            setMessage('Failed to upload/update video. Please try again.');
            console.error(error);
        }
    };

    const handleEdit = (videoId) => {
        const videoToEdit = videos.find((video) => video.id === videoId);
        if (videoToEdit) {
            setEditVideoId(videoId);
            setTitle(videoToEdit.title);
            setUrl(videoToEdit.url);
            setImage(null); // Handle image upload separately
        }
    };

    const handleDelete = async (videoId) => {
        try {
            await axios.delete(`http://127.0.0.1:8000/api/aws-video/${videoId}/`);
            setMessage('Video deleted successfully!');
            fetchVideos(); // Refresh the video list after deletion
        } catch (error) {
            setMessage('Failed to delete video. Please try again.');
            console.error(error);
        }
    };

    return (
        <>
        <AdminNavbar/>
        <Box sx={{ padding: '20px' }}>
            <Typography variant="h4" gutterBottom align="center">
                Upload and View Videos
            </Typography>
            {message && (
                <Alert severity={message.includes('successfully') ? 'success' : 'error'} sx={{ marginBottom: '20px' }}>
                    {message}
                </Alert>
            )}
            <StyledForm onSubmit={handleSubmit}>
                <TextField
                    label="Title"
                    variant="outlined"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    required
                    fullWidth
                />
                <TextField
                    label="YouTube URL"
                    variant="outlined"
                    value={url}
                    onChange={(e) => setUrl(e.target.value)}
                    required
                    fullWidth
                />
                <Button
                    variant="outlined"
                    component="label"
                    sx={{
                        display: 'block',
                        textAlign: 'center',
                        color: '#007BFF',
                        borderColor: '#007BFF',
                        '&:hover': { backgroundColor: '#e3f2fd' },
                    }}
                >
                    Upload Thumbnail
                    <input type="file" hidden onChange={(e) => setImage(e.target.files[0])} />
                </Button>
                <Button
                    type="submit"
                    variant="contained"
                    sx={{
                        backgroundColor: '#007BFF',
                        color: 'white',
                        '&:hover': { backgroundColor: '#0056b3' },
                    }}
                >
                    {editVideoId ? 'Update' : 'Upload'}
                </Button>
            </StyledForm>

            {/* Video Cards */}
            <Box
                sx={{
                    display: 'flex',
                    flexWrap: 'wrap',
                    gap: '20px',
                    marginTop: '40px',
                    justifyContent: 'center',
                }}
            >
                {videos.map((video, index) => (
                    <Card key={video.id} sx={{ maxWidth: 345, boxShadow: 3, marginBottom: '20px' }}>
                        <CardMedia
                            component="img"
                            height="140"
                            image={`http://127.0.0.1:8000${video.image}`} // Prepend the base URL
                            alt={video.title}
                        />
                        <CardContent>
                            <Typography gutterBottom variant="h6" component="div">
                                {index + 1}. {video.title}
                            </Typography>
                            <Typography variant="body2" color="text.secondary">
                                <a href={video.url} target="_blank" rel="noopener noreferrer">
                                    Watch Video
                                </a>
                            </Typography>
                        </CardContent>
                        <CardActions>
                            <Button size="small" color="primary" onClick={() => handleEdit(video.id)}>
                                Edit
                            </Button>
                            <Button size="small" color="secondary" onClick={() => handleDelete(video.id)}>
                                Delete
                            </Button>
                        </CardActions>
                    </Card>
                ))}
            </Box>
        </Box>
        </>
    );
};

export default AwsVideoAdmin;
