import * as React from 'react';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';
import CardActionArea from '@mui/material/CardActionArea';
import Stack from '@mui/material/Stack';
import { useNavigate } from 'react-router-dom';
import AdminNavbar from '../components/AdminNavbar';
// import Navbar from './Navbar';


export default function AwsCardsAdmin() {
  const navigate = useNavigate();
  return (
    <>
    <AdminNavbar/>
    {/* <Navbar/> */}
      {/* Top text section */}
      <div style={{ marginBottom: '50px', textAlign: 'center' }}>
        <Typography variant="h3" sx={{ color: 'text.secondary' }}>
          hey dear, i am your tutor-bot, you can ask me any question.
        </Typography>
      </div>

      {/* Card section */}
      <div>
        <Stack
          direction="row"
          spacing={2}
          sx={{ justifyContent: 'center', alignItems: 'center' }}
        >
          {/* Left small card */}
          <Card sx={{ width: 400, height:500 }} onClick={() => navigate('/Aws-question-Admin')}>
            <CardActionArea>
              <CardMedia
                component="img"
                height="400"
                image="/images/homework.jpg"
                alt="green iguana"
              />
              <CardContent>
                <Typography variant="body2" sx={{ color: 'text.primary', fontSize: '24px', textAlign: 'center' }}>
                  Homework
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>

          {/* Middle large card */}
          <Card sx={{ width: 500, height:500}} onClick={() => navigate('/Aws-Video-Admin')}>
            <CardActionArea>
              <CardMedia
                component="img"
                height="400"
                image="/images/tutor.gif"
                alt="green iguana"
              />
              <CardContent>
                <Typography variant="body2" sx={{ color: 'text.primary', fontSize: '24px', textAlign: 'center' }}>
                  Middle Card
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>

          {/* Right small card */}
          <Card sx={{ width: 400, height:500 }} onClick={() => navigate('/Aws-Mcqs-Admin')}>
            <CardActionArea>
              <CardMedia
                component="img"
                height="400"
                image="/images/tutorbook.jpeg"
                alt="green iguana"
              />
              <CardContent>
                <Typography variant="body2" sx={{ color: 'text.primary', fontSize: '24px', textAlign: 'center' }}>
                  syllabus
                </Typography>
              </CardContent>
            </CardActionArea>
          </Card>
        </Stack>
      </div>
    </>
  );
}


