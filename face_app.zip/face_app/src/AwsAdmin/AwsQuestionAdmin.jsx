import React, { useState, useEffect } from "react";
import axios from "axios";
import AdminNavbar from "../components/AdminNavbar";
// import Navbar from "./Navbar";

const AwsQuestionAdmin = () => {
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [questions, setQuestions] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage] = useState(5);
  const [expandedQuestion, setExpandedQuestion] = useState(null);
  const [editMode, setEditMode] = useState(null); // Stores the ID of the question being edited
  const [inlineEdit, setInlineEdit] = useState(null); // Stores the ID of the question being edited inline

  useEffect(() => {
    fetchQuestions();
  }, []);

  const fetchQuestions = async () => {
    try {
      const response = await axios.get("http://127.0.0.1:8000/api/aws/");
      setQuestions(response.data);
    } catch (error) {
      console.error("Error fetching questions:", error);
    }
  };

  const handleUpload = async () => {
    if (!question || !answer) {
      alert("Please fill out both fields before uploading.");
      return;
    }

    try {
      await axios.post("http://127.0.0.1:8000/api/aws/", { question, answer });
      alert("Question and Answer uploaded successfully!");
      setQuestion("");
      setAnswer("");
      fetchQuestions();
    } catch (error) {
      console.error("Error uploading data:", error);
      alert("Failed to upload. Please try again.");
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://127.0.0.1:8000/api/aws/${id}/`);
      alert("Question deleted successfully!");
      fetchQuestions();
    } catch (error) {
      console.error("Error deleting question:", error);
      alert("Failed to delete. Please try again.");
    }
  };

  const handleInlineEdit = (id) => {
    setInlineEdit(id);
  };

  const handleInlineUpdate = async (id, updatedQuestion, updatedAnswer) => {
    try {
      await axios.put(`http://127.0.0.1:8000/api/aws/update/${id}/`, {
        question: updatedQuestion,
        answer: updatedAnswer,
      });
      alert("Question and Answer updated successfully!");
      setInlineEdit(null);
      fetchQuestions();
    } catch (error) {
      console.error("Error updating data:", error);
      alert("Failed to update. Please try again.");
    }
  };

  const toggleAnswer = (id) => {
    setExpandedQuestion(expandedQuestion === id ? null : id);
  };

  const renderQuestions = () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const selectedQuestions = questions.slice(startIndex, startIndex + itemsPerPage);

    return selectedQuestions.map((item, index) => (
      <>
      <AdminNavbar/>
      <div key={item.id} style={{ border: "1px solid #ddd", padding: "10px", marginBottom: "10px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          {inlineEdit === item.id ? (
            <div style={{ display: "flex", flexDirection: "column", width: "100%" }}>
              <input
                type="text"
                defaultValue={item.question}
                onChange={(e) => (item.question = e.target.value)}
                style={{ marginBottom: "5px", padding: "5px" }}
              />
              <input
                type="text"
                defaultValue={item.answer}
                onChange={(e) => (item.answer = e.target.value)}
                style={{ marginBottom: "5px", padding: "5px" }}
              />
              <button
                onClick={() => handleInlineUpdate(item.id, item.question, item.answer)}
                style={{
                  backgroundColor: "#4CAF50",
                  color: "white",
                  padding: "5px 10px",
                  border: "none",
                  cursor: "pointer",
                  borderRadius: "3px",
                }}
              >
                Save
              </button>
            </div>
          ) : (
            <>
              <span>
                {startIndex + index + 1}. {item.question}
              </span>
              <div>
                <button onClick={() => handleInlineEdit(item.id)} style={{ marginRight: "10px" }}>
                  ✏️ Edit
                </button>
                <button onClick={() => handleDelete(item.id)}>🗑️ Delete</button>
              </div>
            </>
          )}
        </div>
        <button
          onClick={() => toggleAnswer(item.id)}
          style={{ marginTop: "10px", backgroundColor: "#f0f0f0", padding: "5px", border: "none" }}
        >
          {expandedQuestion === item.id ? "Hide Answer" : "Show Answer"}
        </button>
        {expandedQuestion === item.id && (
          <div style={{ marginTop: "10px", border: "1px solid #ccc", padding: "10px" }}>
            <div style={{ display: "flex", justifyContent: "flex-end" }}>
              <button onClick={() => handleInlineEdit(item.id)} style={{ marginRight: "10px" }}>
                ✏️ Edit
              </button>
              <button onClick={() => handleDelete(item.id)}>🗑️ Delete</button>
            </div>
            <p>{item.answer}</p>
          </div>
        )}
      </div>
      </>
    ));
  };

  const totalPages = Math.ceil(questions.length / itemsPerPage);

  return (
    <>
    {/* <Navbar/> */}
    
    <div style={{ padding: "20px", maxWidth: "600px", margin: "0 auto" }}>
      <h3>Upload Question and Answer</h3>
      <div style={{ marginBottom: "10px" }}>
        <label htmlFor="question">Question:</label>
        <input
          type="text"
          id="question"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          style={{ width: "100%", padding: "8px", marginTop: "5px" }}
        />
      </div>
      <div style={{ marginBottom: "10px" }}>
        <label htmlFor="answer">Answer:</label>
        <input
          type="text"
          id="answer"
          value={answer}
          onChange={(e) => setAnswer(e.target.value)}
          style={{ width: "100%", padding: "8px", marginTop: "5px" }}
        />
      </div>
      <button
        onClick={handleUpload}
        style={{
          backgroundColor: "#4CAF50",
          color: "white",
          padding: "10px 15px",
          border: "none",
          cursor: "pointer",
          borderRadius: "5px",
        }}
      >
        Upload
      </button>

      <h3 style={{ marginTop: "20px" }}>Questions</h3>
      {renderQuestions()}

      <div style={{ marginTop: "20px", display: "flex", justifyContent: "space-between" }}>
        <button
          disabled={currentPage === 1}
          onClick={() => setCurrentPage((prev) => prev - 1)}
          style={{ padding: "5px 10px", cursor: "pointer" }}
        >
          Previous
        </button>
        <span>
          Page {currentPage} of {totalPages}
        </span>
        <button
          disabled={currentPage === totalPages}
          onClick={() => setCurrentPage((prev) => prev + 1)}
          style={{ padding: "5px 10px", cursor: "pointer" }}
        >
          Next
        </button>
      </div>
    </div>
    </>
  );
};

export default AwsQuestionAdmin;
