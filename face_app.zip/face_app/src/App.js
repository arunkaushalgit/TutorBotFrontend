import logo from './logo.svg';
import './App.css';
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import SendOtpPage from './components/SendotpPage';
import ForgotPasswordPage from './components/ForgotPasswordPage';
import AdminDashboard from './components/AdminDashboard';
import StudentForm from './components/StudentForm';
import FaceRecognition from './components/FaceRecognition';
import TotalStudents from './components/Students/TotalStudents';
import PresentStudents from './components/Students/PresentStudents';
import AbsentStudents from './components/Students/AbsentStudents';
import StudentProfile from './components/Students/StudentProfile';
import AwsQuestionAdmin from './AwsAdmin/AwsQuestionAdmin';
import AwsVideoAdmin from './AwsAdmin/AwsVideoAdmin';
import AdminNavbar from './components/AdminNavbar';
import AwsCardsAdmin from './AwsAdmin/AwsCardsAdmin';
import AwsQuestion from './AwsUser/AwsQuestion';
import AwsMcqs from './AwsUser/AwsMcqs';
import AwsMcqsAdmin from './AwsAdmin/AwsMcqsAdmin';
import UserDashboard from './components/UserDashboard';
import AwsCardsUser from './AwsUser/AwsCardsUser';
import AwsVideos from './AwsUser/AwsVideos';
import ChangePassword from './components/ChangePassword';
import AwsQuizResults from './AwsUser/AwsQuizResults';
import Constructon from './components/Constructon';

function App() {
  return (
    // <AwsVideos/>
    <Router>
        <Routes>
            <Route path="/student-profile/:studentId" element={<StudentProfile/>} />
            <Route path="/camera" element={<FaceRecognition/>} />
            <Route path="/" element={<LoginPage/>} />
            <Route path="/sign-up" element={<SignupPage/>} />
            <Route path="/otp-page/:email" element={<SendOtpPage/>} />
            <Route path="/forgot-password" element={<ForgotPasswordPage/>} />
            <Route path="/logout" element={<LoginPage/>} />
            <Route path="/change-password" element={<ChangePassword/>} />
            {/* <Route path="/Admin-Dashboard/:userId" element={<AdminNavbar/> } /> */}
            <Route path="/Admin-Dashboard/:userId" element={<AdminDashboard />} />
            <Route path="/User-Dashboard/:userId" element={<UserDashboard/>} />
            {/* <Route path="/User-Dashboard/:userId" element={<Navbar/>} /> */}
            <Route path="/Add-student/:userId" element={<StudentForm/>} />
            {/* <Route path="/Add-Student/:userId" element={<AdminDashboard/>} /> */}
            {/* <Route path="/" element={<AdminDashboard/>} /> */}
            <Route path="/student-profile/:userId" element={<StudentProfile/>} />
            <Route path="/total-students" element={<TotalStudents />} />
            <Route path="/present-students" element={<PresentStudents />} />
            <Route path="/absent-students" element={<AbsentStudents />} />

            <Route path="/Aws-Card-Admin" element={<AwsCardsAdmin/>} />
            <Route path="/Aws-Question-Admin" element={<AwsQuestionAdmin/>} />
            <Route path="/Aws-Video-Admin" element={<AwsVideoAdmin/>} />
            <Route path="/Aws-Mcqs-Admin" element={<AwsMcqsAdmin/> } />

            {/* <Route path="/Aws-Card-User" element={<AwsCardsUser/>} /> */}
            <Route path="/Aws-Question-User/:userId" element={<AwsQuestion/>} />
            <Route path="/Aws-Video-User/:userId" element={<AwsVideos/>} />
            <Route path="/Aws-Mcqs-User/:userId" element={<AwsMcqs/> } />
            <Route path="/Aws-Mcqs-result/:userId" element={<AwsQuizResults/> } />

            <Route path="/under-construction" element={<Constructon/>} />
          </Routes>
    </Router>
  );
}

export default App;
